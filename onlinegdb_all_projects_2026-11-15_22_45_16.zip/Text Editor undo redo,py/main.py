
class TextEditor:
    def __init__(self):  # Define function for initialization
        self.document = ""
        self.undo_stack = []
        self.redo_stack = []

    # Define function for making changes in document
    def make_change(self, change):
        self.undo_stack.append(self.document)
        self.document = self.document + change
        self.redo_stack.clear()
        self.display()

    # Define function for undo the text in document
    def undo_state(self):
        if self.undo_stack:
            self.redo_stack.append(self.document)
            self.document = self.undo_stack.pop()
            print("Undo operation is done!")
            print("Current state of text document:" + self.document + "\n")
        else:
            print("Undo operation can't perform")

    # Define function for redo the text in document
    def redo_state(self):
        if self.redo_stack:
            self.document = self.redo_stack.pop()
            self.undo_stack.append(self.document)
            print("Redo operation is done!")
            print("Current state of text document:" + self.document + "\n")
        else:
            print("Redo operation can't perform")

    # Define function to display the text in document
    def display(self):
        print("Current state of text document:" + self.document + "\n")

    # Define function for Menu providing
    def menu(self):
        while True:
            print("---Menu---")
            print("1.Make change")
            print("2.Undo operation")
            print("3.Redo operation")
            print("4.Display")
            print("5.Exit")

            choice = int(input("Your choice: "))

            if choice == 1:
                change = input("Enter text to add:")
                self.make_change(change)

            elif choice == 2:
                self.undo_state()

            elif choice == 3:
                self.redo_state()

            elif choice == 4:
                self.display()

            elif choice == 5:
                print("Exiting")
                break

            else:
                print("invalid choice!\n\n")


# Run TextEditor
obj1 = TextEditor()  # Creating object
obj1.menu()