event = []

def addEvent(events):
    a = int(input("How many events do you want to add => "))
    events = []
    for i in range(a):
        b = input(f"Enter Event {i+1} name: ")
        event.append(b)
    event.append(events)


def processEvent():
    if event:
        e = event.pop(0)
        print(f"Event {e} is being in process")
    else:
        print("No next longest event is remaining")


def cancelEvent(event_name):
    if event_name in event:
        event.remove(event_name)
        print(f"Event {event_name} is cancelled.")
    else:
        print("No event is found or already proceed.")


def displayEvent():
    if event:
        print("Displaying pending event:")
        # print(event)
        for i in range(len(event)):
            print(event[i])
    else:
        print("No pending event")


def menu():
    while True:
        print("------Menu------")
        print("1. Add New Events")
        print("2. Process Event")
        print("3. Cancel Event")
        print("4. Display Pending Events")
        print("5. Exit")

        choice = int(input("Enter your choice: "))

        if choice == 1:
            addEvent(event)

        elif choice == 2:
            processEvent()

        elif choice == 3:
            e = input("Enter event name for cancellation:")
            cancelEvent(e)

        elif choice == 4:
            displayEvent()

        elif choice == 5:
            print("Exiting from the Event queue")
            break

        else:
            print("Invalid")


menu()