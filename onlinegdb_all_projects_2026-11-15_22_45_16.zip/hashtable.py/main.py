class HashTable:
    def __init__(self, size=10):
        self.size = size
        self.table = [[] for _ in range(size)]

    # Hash function using division method
    def hash_function(self, key):
        return key % self.size

    # Insert a key into the hash table
    def insert_element(self, key):
        index = self.hash_function(key)

        # Check if the key already exists in the chain
        if key in self.table[index]:
            print(f"Element {key} already exists at index {index}.")
            return

        self.table[index].append(key)
        print(f"Key {key} inserted at index {index}.")

    # Search for a key in the hash table
    def search_element(self, key):
        index = self.hash_function(key)

        if key in self.table[index]:
            print(f"Element {key} found at index {index}.")
        else:
            print(f"Element {key} not found in the hash table.")

    # Delete a key from the hash table
    def delete_element(self, key):
        index = self.hash_function(key)

        if key in self.table[index]:
            self.table[index].remove(key)
            print(f"Element {key} deleted from index {index}.")
        else:
            print(f"Element {key} not found. Deletion not possible.")

    # Display the hash table
    def display_HashTable(self):
        print("Hash Table:")
        for i in range(self.size):
            print(f"Index {i}: {self.table[i]}")
        print()

    # Menu-driven program
    def menu(self):
        while True:
            print("----- MENU -----")
            print("1. Insert element in Hash table")
            print("2. Search element in Hash table")
            print("3. Delete element from Hash table")
            print("4. Display Hash table")
            print("5. Exit")

            try:
                choice = int(input("Enter your choice: "))
            except ValueError:
                print("Invalid input. Please enter a number.")
                continue

            if choice == 1:
                print("Size of Hash table is 10!")
                key = int(input("Enter element to insert: "))
                self.insert_element(key)

            elif choice == 2:
                key = int(input("Enter element to search: "))
                self.search_element(key)

            elif choice == 3:
                key = int(input("Enter element to delete: "))
                self.delete_element(key)

            elif choice == 4:
                self.display_HashTable()

            elif choice == 5:
                print("Exiting...")
                break

            else:
                print("Invalid choice. Try again.")


# Main program
obj1 = HashTable()
obj1.menu()