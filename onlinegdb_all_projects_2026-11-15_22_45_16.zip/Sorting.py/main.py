# Menu Driven program for sorting

salary = int(input("Enter the length of salary list: "))
salaries = []

for i in range(salary):
    s = int(input(f"Enter salary{i+1}: "))
    salaries.append(s)
    print(salaries)

# Bubble sort
def bubble_sort(salary_list):
    n = len(salary_list)

    for i in range(n):  # traversing
        for j in range(n - i - 1):  # comparing adjacent elements
            if salary_list[j] > salary_list[j + 1]:
                salary_list[j], salary_list[j + 1] = salary_list[j + 1], salary_list[j]

    return salary_list

# Selection sort
def selection_sort(salary_list):
    n = len(salary_list)

    for i in range(n):
        min_index = i

        for j in range(i + 1, n):
            if salary_list[j] < salary_listsalary_list[j] salary_list[min_index] = (
                    salary_list[min_index],
                    salary_list[j]
                )

    return salary_list

# Menu
while True:
    print("---Sorting operation---")
    print("Select your choice.")
    print("1. Bubble sort")
    print("2. Selection sort")
    print("3. Exit")
    print("Start...")

    choice = int(input("Your choice: "))

    if choice == 1:
        a = bubble_sort(salaries)
        print("Sorting salary list by using Bubble sort:\n", a)
        print("\nExit")
        break

    elif choice == 2:
        a = selection_sort(salaries)
        print("Sorting salary list by using Selection sort:\n", a)
        print("\nExit")
        break

    elif choice == 3:
        print("Exiting from program.\nThank you!")
        break

    else:
        print("Invalid choice!\n")
        print("Visit again!")